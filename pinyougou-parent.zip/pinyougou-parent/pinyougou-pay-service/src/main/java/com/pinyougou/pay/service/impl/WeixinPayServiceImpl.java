package com.pinyougou.pay.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;

import com.alibaba.dubbo.config.annotation.Service;
import com.github.wxpay.sdk.WXPay;
import com.github.wxpay.sdk.WXPayUtil;
import com.pinyougou.pay.service.WeixinPayService;

import util.HttpClient;

@Service
public class WeixinPayServiceImpl implements WeixinPayService {

	@Value("${appid}")
	private String appid;
	
	@Value("${partner}")
	private String partner;
	
	@Value("${partnerkey}")
	private String partnerkey;
	
	@Value("${notifyurl}")
	private String notifyurl;
	
	
	@Override
	public Map createNative(String out_trade_no, String total_fee) {
		Map map = new HashMap<>();
		map.put("appid", appid);//公众账号ID
		map.put("mch_id", partner);//商户号
		map.put("nonce_str", WXPayUtil.generateNonceStr());//随机字符串
		map.put("body", "精品半身裙");//商品描述
		map.put("out_trade_no", out_trade_no);//商户订单号
		map.put("total_fee", total_fee);//标价金额
		map.put("spbill_create_ip", "127.0.0.1");//终端IP
		map.put("notify_url", notifyurl);//通知地址
		map.put("trade_type", "NATIVE");//交易类型
		
		try {
			String xmlParam = WXPayUtil.generateSignedXml(map, partnerkey);
			HttpClient client= new HttpClient("https://api.mch.weixin.qq.com/pay/unifiedorder");
			client.setHttps(true);
			client.setXmlParam(xmlParam);
			client.post();
			
			String result = client.getContent();
			Map resultMap=WXPayUtil.xmlToMap(result);
			
			Map returnMap= new HashMap<>();
			if("SUCCESS".equals(resultMap.get("return_code"))&&"SUCCESS".equals(resultMap.get("result_code"))){
				String code_url = (String) resultMap.get("code_url");//支付链接
				returnMap.put("code_url", code_url);
				returnMap.put("out_trade_no", out_trade_no);
				returnMap.put("total_fee", total_fee);
			}else{
				System.out.println(resultMap.get("err_code"));
			}
			
			return returnMap;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new HashMap<>();
		}
		
		
	}


	@Override
	public Map queryPayStatus(String out_trade_no) {
		Map map= new HashMap<>();
		map.put("appid", appid);//公众账号ID
		map.put("mch_id", partner);//商户号
		map.put("out_trade_no", out_trade_no);//商户订单号
		map.put("nonce_str", WXPayUtil.generateNonceStr());//随机字符串
		try {
			String xmlParam=WXPayUtil.generateSignedXml(map, partnerkey);
			
			HttpClient client= new HttpClient("https://api.mch.weixin.qq.com/pay/orderquery");
			client.setHttps(true);
			client.setXmlParam(xmlParam);
			client.post();
			String result = client.getContent();
			return WXPayUtil.xmlToMap(result);
			
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
		
	}


	@Override
	public Map closeOrder(String out_trade_no) {
		Map map = new HashMap<>();
		map.put("appid", appid);//
		map.put("mch_id", partner);//
		map.put("out_trade_no", out_trade_no);//
		map.put("nonce_str", WXPayUtil.generateNonceStr());//
		
		try {
			String xmlParam = WXPayUtil.generateSignedXml(map, partnerkey);
			
			HttpClient client= new HttpClient("https://api.mch.weixin.qq.com/pay/closeorder");
			client.setHttps(true);
			client.setXmlParam(xmlParam);
			
			client.post();
			String result = client.getContent();
			
			return WXPayUtil.xmlToMap(result);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}
