app.controller('baseController',function($scope){
	
	
	
	//分页控件配置 
	$scope.paginationConf = {
			 currentPage: 1,
			 totalItems: 10,
			 itemsPerPage: 10,
			 perPageOptions: [10, 20, 30, 40, 50],
			 onChange: function(){//任意参数变化时，执行方法
			        	 $scope.reloadList();//重新加载
			 }
	}; 

	//刷新页面
	$scope.reloadList=function(){
		 $scope.search($scope.paginationConf.currentPage,$scope.paginationConf.itemsPerPage);
	}
	
	$scope.seleteIds=[];
	
	//选择id
	$scope.updateSelection=function($event,id){
		if($event.target.checked){//true 勾选
			$scope.seleteIds.push(id);
		}else{//取消勾选  1元素在数组中的索引位置 2移除的个数
			var index=$scope.seleteIds.indexOf(id);//获取元素在数组中的索引位置
			$scope.seleteIds.splice(index,1);
		}
	}
})