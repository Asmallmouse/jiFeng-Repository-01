//定义控制器
app.controller('brandController',function($scope,$controller,brandService){
	
	//1被继承的控制器名称，2$scope 被继承的（baseController的），$scope（brandController）
	$controller('baseController',{$scope:$scope});
	
	//查询品牌列表   
	//http://localhost:9101/brand/findAll.do
	//http://localhost:9101/admin/brand.html
	
	$scope.findAll=function(){
		brandService.findAll().success(
			function(response){
				$scope.list=response;
			}		
		);
	}
	
	
	
	//分页查询
	$scope.findPage=function(page,rows){
		brandService.findPage(page,rows).success(
				function(response){
					$scope.list=response.rows;
					$scope.paginationConf.totalItems=response.total;//总条数
				}
		);
	}

	$scope.searchEntity={};

	//分页条件查询
	$scope.search=function(page,rows){
		brandService.search(page,rows,$scope.searchEntity).success(
				function(response){
					$scope.list=response.rows;
					$scope.paginationConf.totalItems=response.total;//总条数
				}
		);
	}
	
	//新增和修改品牌
	$scope.save=function(){
		//如果品牌对象中包含id就调用修改方法，否则是调用新增方法
		var methodName;
		if($scope.entity.id!=null){
			methodName=brandService.update($scope.entity);
		}else{
			methodName=brandService.add($scope.entity);
		}
		methodName.success(
			function(response){
				if(response.success){//新增成功
					alert(response.message);
					//刷新页面
					$scope.reloadList();
				}else{
					alert(response.message);
				}
			}	
		);
	}
	
	//数据回显
	$scope.findOne=function(id){
		brandService.findOne(id).success(
			function(response){
				$scope.entity=response;
			}		
		);
	}
	
	
	
	//删除品牌批量
	$scope.dele=function(){
		brandService.dele($scope.seleteIds).success(
				function(response){
					$scope.seleteIds=[];
					if(response.success){//新增成功
						alert(response.message);
						//刷新页面
						$scope.reloadList();
					}else{
						alert(response.message);
					}
				}		
		);
	}
});