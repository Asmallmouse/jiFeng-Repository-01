//定义模块
var app= angular.module('pinyougou',['pagination']);