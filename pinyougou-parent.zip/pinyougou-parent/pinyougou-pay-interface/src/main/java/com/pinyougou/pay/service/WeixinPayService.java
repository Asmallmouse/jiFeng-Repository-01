package com.pinyougou.pay.service;

import java.util.Map;

public interface WeixinPayService {

	/**
	 * 调用统一下单API获取支付链接
	 * @param out_trade_no 交易订单号  支付日志的id
	 * @param total_fee 支付的金额 单位分
	 * @return 支付的连接、支付订单号、支付金额
	 */
	public Map createNative(String out_trade_no,String total_fee);
	
	
	/**
	 *  查询订单支付状态
	 * @param out_trade_no 被查询的订单号
	 * @return 返回结果
	 */
	public Map queryPayStatus(String out_trade_no);
	
	
	/**
	 * 关闭订单
	 * @param out_trade_no 订单号
	 * @return
	 */
	public Map closeOrder(String out_trade_no);
}
