package com.pinyougou.cart.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;

import com.alibaba.dubbo.config.annotation.Service;
import com.pinyougou.cart.service.CartService;
import com.pinyougou.mapper.TbItemMapper;
import com.pinyougou.pojo.Cart;
import com.pinyougou.pojo.TbItem;
import com.pinyougou.pojo.TbOrderItem;

@Service
public class CartServiceImpl implements CartService {
	
	@Autowired
	private TbItemMapper itemMapper;
	
	
	@Autowired
	private RedisTemplate redisTemplate;

	@Override
	public List<Cart> addGoodsToCartList(List<Cart> cartList, Long itemId, Integer num) {
		//1根据itemId获取sku数据 
		TbItem item = itemMapper.selectByPrimaryKey(itemId);
		if(item==null){
			throw new RuntimeException("该商品不存在");
		}
		if(!"1".equals(item.getStatus())){
			throw new RuntimeException("该商品状态异常");
		}
		//2通过item数据得到商家信息
		String sellerId=item.getSellerId();
		//3购物车列表中是否有商家的购物车对象 返回购物车对象
		Cart cart=searchCartBySellerId(cartList,sellerId);
		
		//3.1没有
		if(cart==null){
			//创建新的购物车对象（创建商品明细构建商品明细列表），追加到列表中
			cart=new Cart();
			cart.setSellerId(item.getSellerId());
			cart.setSellerName(item.getSeller());
			List<TbOrderItem> orderItemList= new ArrayList<>();
			TbOrderItem orderItem=createOrderItem(item,num);
			orderItemList.add(orderItem);
			cart.setOrderItemList(orderItemList);
			//将新建的cart追加到购物车列表中
			cartList.add(cart);
		}else{//3.2有
			//判断该购物车中是否有当前商品的明细
			TbOrderItem orderItem=findOrderItemByItemId(cart.getOrderItemList(),itemId);
			if(orderItem==null){//如果没该商品明细 创建商品明细
				orderItem=createOrderItem(item,num);
				cart.getOrderItemList().add(orderItem);
			}else{//如果有 修改购买数量和小计
				orderItem.setNum(orderItem.getNum()+num);
				orderItem.setTotalFee(new BigDecimal(orderItem.getPrice().doubleValue()*orderItem.getNum()));
				if(orderItem.getNum()<=0){//有可能减 购物车明细数量小于等于0
					cart.getOrderItemList().remove(orderItem);
				}
				if(cart.getOrderItemList().size()==0){//购物车对象中明细列表为空删除购物车
					cartList.remove(cart);
				}
			}
		}
		return cartList;
	}

	//通过SKUid判断该商品明细列表中是否有该商品的明细信息
	private TbOrderItem findOrderItemByItemId(List<TbOrderItem> orderItemList, Long itemId) {
		for (TbOrderItem orderItem : orderItemList) {
			if(orderItem.getItemId().longValue()==itemId.longValue()){
				return orderItem;
			}
		}
		return null;
	}

	//根据SKU商品数据和购买数量构建商品明细对象
	private TbOrderItem createOrderItem(TbItem item, Integer num) {
		if(num<=0){
			throw new RuntimeException("数量非法");
		}
		TbOrderItem orderItem = new TbOrderItem();
		orderItem.setGoodsId(item.getGoodsId());
		orderItem.setItemId(item.getId());
		orderItem.setNum(num);
		orderItem.setPicPath(item.getImage());
		orderItem.setPrice(item.getPrice());
		orderItem.setSellerId(item.getSellerId());
		orderItem.setTitle(item.getTitle());
		orderItem.setTotalFee(new BigDecimal(item.getPrice().doubleValue()*num));
		return orderItem;
	}

	//判断购物车列表中是否有该商家的购物车对象
	private Cart searchCartBySellerId(List<Cart> cartList, String sellerId) {
		for (Cart cart : cartList) {
			if(cart.getSellerId().equals(sellerId)){
				return cart;
			}
		}
		return null;
	}

	@Override
	public List<Cart> findCartListFromRedis(String username) {
		List<Cart> cartList=(List<Cart>) redisTemplate.boundHashOps("cartList").get(username);
		
		if(cartList==null){
			cartList=new ArrayList<>();
		}
		return cartList;
	}

	@Override
	public void addCartListToRedis(String username, List<Cart> cartList) {
		redisTemplate.boundHashOps("cartList").put(username, cartList);
	}

	@Override
	public List<Cart> mergeCartList(List<Cart> cartList1, List<Cart> cartList2) {
		for (Cart cart : cartList2) {
			for(TbOrderItem orderItem :cart.getOrderItemList()){
				 cartList1 = addGoodsToCartList(cartList1,orderItem.getItemId(),orderItem.getNum());
			}
		}
		return cartList1;
	}

}
