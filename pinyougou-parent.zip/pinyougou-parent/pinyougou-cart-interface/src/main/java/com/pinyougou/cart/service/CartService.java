package com.pinyougou.cart.service;

import java.util.List;

import com.pinyougou.pojo.Cart;

public interface CartService {

	/**
	 * 将商品添加到购物车
	 * @param cartList 从cookie中获取到了购物车列表
	 * @param itemId SKUid
	 * @param num 购买数量
	 * @return 新的购物车列表
	 */
	public List<Cart> addGoodsToCartList(List<Cart> cartList,Long itemId,Integer num);
	
	
	/**
	 * 获取当前登陆用户的购物车
	 * @param username 用户名
	 * @return
	 */
	public List<Cart> findCartListFromRedis(String username);
	
	
	/**
	 * 将当前买家的购物车存入到redis中
	 * @param username
	 * @param cartList
	 */
	public void addCartListToRedis(String username,List<Cart> cartList);
	
	
	/**
	 * 购物车列表合并
	 * @param cartList1 redis的购物车
	 * @param cartList2 cookie中的购物车
	 * @return
	 */
	public List<Cart> mergeCartList(List<Cart> cartList1,List<Cart> cartList2);
	
}
