app.controller('itemController',function($scope,$http){
	//x添加的数量
	$scope.addNum=function(x){
		$scope.num=parseInt($scope.num)+x//最终的购买数量
		if($scope.num<1){
			$scope.num=1;
		}
	}
	
	$scope.specification={};//记录用户选择行为
	
	$scope.selectSpec=function(name,value){
		$scope.specification[name]=value;
		$scope.searchSku();//切换SKU
	}
	
	
	$scope.isSelected=function(name,value){
		//$scope.specification={"网络":"联通4G","机身内存":"32G"};
		if($scope.specification[name]==value){
			return true;
		}else{
			return false;
		}
		
	}
	
	$scope.sku={};//当前的SKU对象
	
	//加载默认的SKU
	$scope.loadSku=function(){
		//{id:1369291,title:'外星人台式机 移动4G 32G',price:10,spec:{"网络":"移动4G","机身内存":"32G"}}
		$scope.sku=skuList[0];//让默认的SKU对象为当前的SKU
		//将默认的SKU的规格作为默认选中的规格
		$scope.specification=JSON.parse(JSON.stringify($scope.sku.spec));//浅克隆==>深克隆
	}
	
	$scope.searchSku=function(){
		//skuList
		//$scope.specification
		for(var i=0;i<skuList.length;i++){
			if(matchObject(skuList[i].spec,$scope.specification)){
				$scope.sku=skuList[i];
			}
			
		}
	
	}
	
	//{"网络":"移动4G"}
	//{"网络":"移动4G","机身内存":"32G"}
	matchObject=function(map1,map2){
		for(var key in map1){
			if(map1[key]!=map2[key]){
				return false;
			}
		}
		for(var key in map2){
			if(map1[key]!=map2[key]){
				return false;
			}
		}
		return true;
	}
	
	
	$scope.addToCart=function(){
		$http.get('http://localhost:9107/cart/addGoodsToCartList.do?itemId='+$scope.sku.id+'&num='+$scope.num,{'withCredentials':true}).success(
				function(response){
					if(response.success){
						//页面跳转
						location.href="http://localhost:9107/cart.html";
					}else{
						alert(response.message);
					}
					
				}
		)
		
	}
	
})