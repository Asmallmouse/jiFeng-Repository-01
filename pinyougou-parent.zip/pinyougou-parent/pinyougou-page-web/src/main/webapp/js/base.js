//定义模块
var app= angular.module('pinyougou',[]);

//定义一个过滤器  1过滤器名 
app.filter('trustHtml',['$sce',function($sce){
	return function(data){
		return $sce.trustAsHtml(data);
	}
}]);