//购物车控制层 
app.controller('cartController',function($scope,cartService,addressService,orderService){
	
	$scope.entity={paymentType:1};//订单对象  前台提交的数据有支付方式和收货人信息
	
	$scope.submitOrder=function(){
		//设置收货信息
		$scope.entity.receiverAreaName=$scope.address.address;//收货地址
		$scope.entity.receiverMobile=$scope.address.mobile;//收货人联系方式
		$scope.entity.receiver=$scope.address.contact;//收货人
		orderService.submitOrder($scope.entity).success(
				function(response){
					if(response.success){
						if($scope.entity.paymentType==1){//在线支付
							location.href="pay.html";
						}else{//货到付款
							location.href="paysuccess.html";
						}
					}else{
						alert(response.message);
					}
				}
		);
	}
	
	
	//选择支付方式
	$scope.selectPayType=function(type){
		$scope.entity.paymentType=type;
		alert($scope.entity.paymentType);
	}
	
	
	//记录用户选择行为
	$scope.selectAddress=function(address){
		$scope.address=address;//选择的对象
	}
	
	$scope.checkStatus=function(address){
		if($scope.address==address){
			return true;
		}
		return false;
	}
	
	
	
	
	
	
	//查询购物车列表
	$scope.findCartList=function(){
		cartService.findCartList().success(
			function(response){
				$scope.cartList=response;
				$scope.totalValue=cartService.sum($scope.cartList);
			}
		);
		
	}
	
	$scope.addGoodsToCartList=function(itemId,num){
		cartService.addGoodsToCartList(itemId,num).success(
				function(response){
					if(response.success){
						$scope.findCartList();//刷新购物车列表
					}else{
						alert(response.message);
					}
				}
		);
	}
	
	$scope.findAddressList=function(){
		addressService.findAddressList().success(
				function(response){
					//获取收货人地址列表
					$scope.addressList=response;
					for(var i=0;i<$scope.addressList.length;i++){
						if($scope.addressList[i].isDefault==1){
							$scope.selectAddress($scope.addressList[i]);
						}
					}
				}
		);
	}
	
	
});
