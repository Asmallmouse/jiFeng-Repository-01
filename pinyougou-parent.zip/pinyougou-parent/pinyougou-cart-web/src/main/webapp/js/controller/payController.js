app.controller('payController' ,function($scope ,payService,$location){
	
	$scope.createNative=function(){
		payService.createNative().success(
				function(response){
					$scope.out_trade_no=response.out_trade_no;
					$scope.total_fee=(response.total_fee/100).toFixed(2);
					$scope.code_url=response.code_url;
					
					var qr=new QRious({
						element:document.getElementById('qrious'),
						size:300,
						level:'H',
						value:$scope.code_url
					});
					$scope.queryPayStatus();//生成二维码后就开始循环查询支付状态
				}
		);
	}
	
	
	$scope.loadMoney=function(){
		$scope.total_fee=$location.search()['total_fee'];
	}
	
	$scope.queryPayStatus=function(){
		payService.queryPayStatus($scope.out_trade_no).success(
				function(response){
					if(response.success){
						location.href="paysuccess.html#?total_fee="+$scope.total_fee;
					}else{
						if(response.message=='支付超时'){//重新的生成二维码
							alert(response.message);
							$scope.createNative();
						}else{
							alert(response.message);
						}
					}
				}
		);
	}
	
	
	
});