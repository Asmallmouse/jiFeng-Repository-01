package com.pinyougou.cart.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.dubbo.config.annotation.Reference;
import com.pinyougou.order.service.OrderService;
import com.pinyougou.pay.service.WeixinPayService;
import com.pinyougou.pojo.TbPayLog;

import entity.Result;
import util.IdWorker;



@RestController
@RequestMapping("/pay")
public class WeixinPayController {

	@Autowired
	private RedisTemplate redisTemplate;
	
	@Reference
	private WeixinPayService weixinPayService;
	
	@Reference
	private OrderService orderService;
	
	@RequestMapping("/createNative")
	public Map createNative(){
		String userId = SecurityContextHolder.getContext().getAuthentication().getName();
		//支付日志中获取
		TbPayLog payLog = (TbPayLog) redisTemplate.boundHashOps("payLog").get(userId);
		if(payLog==null){
			return new HashMap<>();
		}
		//根据支付日志生成二维码
		return weixinPayService.createNative(payLog.getOutTradeNo(),payLog.getTotalFee()+"");
		
	}
	
	@RequestMapping("/queryPayStatus")
	public Result queryPayStatus(String out_trade_no){
		
		int i=0;
		while(true){
			try {
				Map map = weixinPayService.queryPayStatus(out_trade_no);
				if(map==null){
					return new Result(false, "支付失败");
				}
				if("SUCCESS".equals(map.get("trade_state"))){//支付成功
					//修改支付日志和订单的状态
					orderService.updateOrderStatus(out_trade_no, map.get("transaction_id")+"");
					return new Result(true, "支付成功");
				}
				
				Thread.sleep(3000);
				
				i++;
				if(i>10){
					return new Result(false, "支付超时");
				}
				
			} catch (Exception e) {
				e.printStackTrace();
				return new Result(false, "支付失败");
			}
			
			
			
			
		}
		
		
	}
	
}
