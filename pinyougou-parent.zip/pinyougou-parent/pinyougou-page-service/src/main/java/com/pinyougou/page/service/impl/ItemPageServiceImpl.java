package com.pinyougou.page.service.impl;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;


import com.pinyougou.mapper.TbGoodsDescMapper;
import com.pinyougou.mapper.TbGoodsMapper;
import com.pinyougou.mapper.TbItemCatMapper;
import com.pinyougou.mapper.TbItemMapper;
import com.pinyougou.page.service.ItemPageService;
import com.pinyougou.pojo.TbGoods;
import com.pinyougou.pojo.TbGoodsDesc;
import com.pinyougou.pojo.TbItem;
import com.pinyougou.pojo.TbItemExample;
import com.pinyougou.pojo.TbItemExample.Criteria;

import freemarker.core.ParseException;
import freemarker.template.Configuration;
import freemarker.template.MalformedTemplateNameException;
import freemarker.template.Template;
import freemarker.template.TemplateNotFoundException;


@Service
public class ItemPageServiceImpl implements ItemPageService {

	
	@Autowired
	private FreeMarkerConfigurer freemarkerConfig;
	
	@Autowired
	private TbGoodsMapper goodsMapper;
	
	@Autowired
	private TbGoodsDescMapper goodsDescMapper;
	
	@Autowired
	private TbItemMapper itemMapper;
	
	@Autowired
	private TbItemCatMapper itemCatMapper;
	
	
	@Override
	public void genHtml(Long goodsId) {
		Configuration configuration =freemarkerConfig.getConfiguration();
		try {
			//得到模板对象
			Template template = configuration.getTemplate("item.ftl");
			//得到数据模型 tbgoods tbgoodsDesc tbitem
			Map dataModel=new HashMap<>();
			TbGoods goods = goodsMapper.selectByPrimaryKey(goodsId);
			dataModel.put("goods", goods);//基本信息
			TbGoodsDesc goodsDesc = goodsDescMapper.selectByPrimaryKey(goodsId);
			dataModel.put("goodsDesc", goodsDesc);//扩展信息
			
			TbItemExample example=new TbItemExample();
			Criteria criteria = example.createCriteria();
			criteria.andStatusEqualTo("1");//正常的商品
			criteria.andGoodsIdEqualTo(goodsId);//外键条件
			example.setOrderByClause("is_default desc");
			List<TbItem> itemList = itemMapper.selectByExample(example);
			dataModel.put("itemList", itemList);//SKU详情信息
			
			
			//面包屑数据
			
			String category1name=itemCatMapper.selectByPrimaryKey(goods.getCategory1Id()).getName();
			String category2name=itemCatMapper.selectByPrimaryKey(goods.getCategory2Id()).getName();
			String category3name=itemCatMapper.selectByPrimaryKey(goods.getCategory3Id()).getName();
			
			dataModel.put("category1name", category1name);
			dataModel.put("category2name", category2name);
			dataModel.put("category3name", category3name);
			
			
			//输出流
			Writer out = new FileWriter("D:/item/"+goodsId+".html");
			
			//生成文件
			template.process(dataModel, out);
			out.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		} 

	}


	@Override
	public void deleteHtml(Long goodsId) {
		new File("D:/item/"+goodsId+".html").delete();
	}

}
