package com.pinyougou.page.service;

public interface ItemPageService {

	/**
	 * 为每个SPU生成一个静态页面
	 * @param goodsId SPUid
	 */
	public void genHtml(Long goodsId);
	
	
	/**
	 * 删除商品删除静态页
	 * @param goodsId
	 */
	public void deleteHtml(Long goodsId);
	
}
